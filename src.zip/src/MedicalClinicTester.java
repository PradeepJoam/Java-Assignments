
public class MedicalClinicTester 
{
	public static void main(String[] args) 
	{	
		MedicalClinic m=new MedicalClinic();
		m.menu();
	}
}
