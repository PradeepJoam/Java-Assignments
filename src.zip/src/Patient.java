
public class Patient 
{
	private String firstName;
	private String lastName;
	private int HealthCardNumber;
	private OurDate birthdate;
	private Appointments appointment;
	
	public Patient()
	{
		
	}
	public Patient(String fname,String lname,int hnum,OurDate bday)
	{
		setFirstName(fname);
		setLastName(lname);
		setHealthCardNumber(hnum);
		setBirthdate(bday);
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getHealthCardNumber() {
		return HealthCardNumber;
	}
	public void setHealthCardNumber(int healthCardNumber) {
		HealthCardNumber = healthCardNumber;
	}
	public OurDate getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(OurDate birthdate) {
		this.birthdate = birthdate;
	}
	public Appointments getAppointment() {
		return appointment;
	}
	public void setAppointment(Appointments appointment) {
		this.appointment = appointment;
	}
	
	public String toString()
	{
		return "Patient [firstName="+getFirstName()+", lastName="+getLastName()+", birthDate="+birthdate.toString()+", healthCardNumber="+getHealthCardNumber()+"]";
	}
}
