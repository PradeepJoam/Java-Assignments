import java.util.Scanner;

public class MedicalClinic 
{
	Appointments[] appointment=new Appointments[10];
	Patient[] patient=new Patient[10];
	Doctor[] doctor=new Doctor[5];
	int maxAppointment=10;
	int MAXPATIENT=10;
	int MAXDOCTORS=5;
	int appointmentNumber=0;
	int numberPatients=0;
	int numberDoctors=0;
	Scanner in=new Scanner(System.in);
	
	public MedicalClinic()
	{
		Doctor d1=new Doctor("Vikash","Singh","ortho");
		Doctor d2=new Doctor("Susan", "Miller", "physio");
		Doctor d3=new Doctor("Thanh", "Do", "phycatrist");
		Doctor d4=new Doctor("Francois", "DaSliva", "neurologist");
		Doctor d5=new Doctor("Judy", "Chin", "heart");
		doctor[0]=d1;
		doctor[1]=d2;
		doctor[2]=d3;
		doctor[3]=d4;
		doctor[4]=d5;
	}
	
	public void menu()
	{
		int choice=0;
		while(choice!=4)
		{
			System.out.println("Please make a choice:");
			System.out.println("1. Enter a new patient");
			System.out.println("2. Make an appointment for a patient");
			System.out.println("3. List all appointments");
			System.out.println("4. Quit");
			choice=in.nextInt();
			if(choice==1)
			{
				addPatient();
			}
			else if(choice==2)
			{
				addAppointment();
			}
			else if(choice==3)
			{
				listAppointment();
			}
			else if(choice==4)
			{
				System.out.println("Goodbye");
			}
			else
			{
				System.out.println("Wrong choice");
			}
		}
		
	}
	public void addPatient()
	{
		System.out.println("Enter First Name:");
		String fn=in.next();
		System.out.println("Enter last name:");
		String ln=in.next();
		System.out.println("Enter Health card number:");
		int hno=in.nextInt();
		System.out.println("Enter birthdate DDMMYYYY:");
		String dt=in.next();
		
		int day=Integer.parseInt(dt.substring(0,2));
		int mon=Integer.parseInt(dt.substring(2,4));
		int yer=Integer.parseInt(dt.substring(4));
		OurDate d=new OurDate(day,mon,yer);
		
		Patient p=new Patient(fn,ln,hno,d);
		patient[numberPatients]=p;
		numberPatients++;
	}
	
	public void addAppointment()
	{
		System.out.println("Enter health card number");
		int hcard=in.nextInt();
		int i=0;
		Patient ap=null ;
		for (Patient var : patient) 
		{ 
			if(var!=null)
			{
			    if(hcard==var.getHealthCardNumber())
			    {
			    	ap=var;
			    	i++;
			    }
			}
			
		}
		
		if(i>0)
		{
			System.out.println(ap.toString());
			
			System.out.println();
			System.out.println("Please make a choice");
			int j=1;
			
			for(Doctor d:doctor)
			{
				if(d!=null)
				{
					System.out.println(j+" "+d.getFirstName()+" "+d.getLastName());
					j++;
				}
			}
			System.out.println("Enter number for doctor selection");
			int ch=in.nextInt();
			Doctor chdoctor=doctor[ch-1];
			
			System.out.println("Enter desired date DDMMYYYY");
			int date=in.nextInt();
			String dt=date+"";
			int day=Integer.parseInt(dt.substring(0,2));
			int mon=Integer.parseInt(dt.substring(2,4));
			int yer=Integer.parseInt(dt.substring(4));
			OurDate d=new OurDate(day,mon,yer);
			
			Appointments apot=new Appointments();
			apot.setDoctor(chdoctor);
			apot.setDate(d);
			apot.setPatient(ap);
			appointment[appointmentNumber]=apot;
			appointmentNumber++;
			
		}
		else
		{
			System.out.println("No patient added");
		}
		
	}
	public void listAppointment()
	{
		int h=0;
		for(Appointments apoint:appointment)
		{
			if(apoint!=null)
			{
				h++;
				System.out.println("Appointment["+apoint.toString()+"]");
			}
		}
		if(h==0)
		{
			System.out.println("No Appointments");
		}
	}
}
