public class Appointments 
{
	private Doctor doctor;
	private Patient patient;
	private OurDate date;
	
	public Appointments()
	{
		
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public OurDate getDate() {
		return date;
	}

	public void setDate(OurDate date) {
		this.date = date;
	}
	
	public String toString()
	{
		return "appointments="+date.toString()+", "+doctor.toString()+", patient="+patient.toString();
		
	}
	
	
	
}
