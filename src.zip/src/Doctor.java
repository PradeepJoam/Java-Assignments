
public class Doctor 
{
	private String firstName;
	private String lastName;
	private String speciality;
	
	public Doctor()
	{
		
	}
	public Doctor(String fname,String lname,String special)
	{
		setFirstName(fname);
		setLastName(lname);
		setSpeciality(special);
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSpeciality() {
		return speciality;
	}
	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
	
	public String toString()
	{
		return "doctor="+getLastName()+", "+getFirstName()+", "+getSpeciality();
		
	}

}
