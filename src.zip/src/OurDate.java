
public class OurDate 
{
	private int Day,Month,Year;

	public OurDate()
	{
		
	}
	public OurDate(int day,int month, int year)
	{
		setDay(day);
		setMonth(month);
		setYear(year);
	}
	public int getDay() {
		return Day;
	}

	public void setDay(int day) {
		Day = day;
	}

	public int getMonth() {
		return Month;
	}

	public void setMonth(int month) {
		Month = month;
	}

	public int getYear() {
		return Year;
	}

	public void setYear(int year) {
		Year = year;
	}
	
	@Override
	public String toString() 
	{
		return "day="+getDay()+", month="+getMonth()+", year="+getYear();
	}
}
